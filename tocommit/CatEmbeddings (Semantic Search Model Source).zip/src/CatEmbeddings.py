import logging
from typing import Any, List
import numpy as np
from sentence_transformers import SentenceTransformer
import time

log = logging.getLogger()

class CatEmbeddings():

    def __init__(self):
        self.sentence_transformer = None
        log.info("\n\n********************************************\nModel CatEmbeddings Initialized!\n********************************************\n")  

    def predict(self, X: np.ndarray, names=None, **kwargs) -> List[Any]:
        if not self.sentence_transformer:
            log.info("Loading sentence transformer model...")
            self.sentence_transformer = SentenceTransformer("cat-sentence-transformer")
            log.info("\n\n********************************************\nModel CatEmbeddings Loaded!\n********************************************\n")
        start_time = time.time()
        model_input = dict(zip(names, X))
        log.info("Input data: %s", model_input)
        text = model_input.get("text")
        log.info("Generating vector embedding for input text: " + text)
        try:
            #Encode vector
            vector = self.sentence_transformer.encode(text)
        except Exception as error:
            log.error("An error occurred: ")
            log.error(error)
            log.error("\n---------------------------------------------\n")
      
        end_time = time.time()
        duration = end_time - start_time
        log.info(f"Embedding vector generated. Duration: {duration} seconds")
        return vector

#pred = CatEmbeddings()
#print(pred.predict(["dozer"],["text"]))

