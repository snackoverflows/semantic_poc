import logging
from typing import Any, List, Iterable
import numpy as np
from transformers import pipeline

log = logging.getLogger()

class CatPredict():

    def __init__(self):
        self.classifier = None
        log.info("\n\n********************************************\nModel CatPredict Initialized!\n********************************************\n")  

    def predict(self, X: np.ndarray, names=None, **kwargs) -> List[Any]:

        if not self.classifier:
            log.info("Loading model...")
            self.classifier = pipeline("text-classification", model=r"cat-classifier")
            log.info("\n\n********************************************\nModel CatPredict Loaded!\n********************************************\n")  
        model_input = dict(zip(names, X))
        log.info("Input data: %s", model_input)
        keyword = model_input.get("query")
        log.info("Predicting for terms: " + keyword)
        try:
            preds = self.classifier(keyword)
        except Exception as error:
            log.error("An error occurred: ")
            log.error(error)
            log.error("\n---------------------------------------------\n")
        log.info("Prediction completed: ")
        log.info(preds)
        return preds

#pred = CatPredict()
#pred.predict([],[])
